# Apex POS — Progressive Web App

## Files
- `index.html` — Full app (self-contained HTML/CSS/JS)
- `manifest.json` — PWA manifest (name, icons, display mode)
- `sw.js` — Service worker (offline caching)
- `icon-192.svg` / `icon-512.svg` — App icons

## How to install on Android

### Option A: Host on GitHub Pages (free, 5 min)
1. Create a free account at github.com
2. New repository → upload all 5 files
3. Go to Settings → Pages → Source: main branch
4. Your app is live at: `https://yourusername.github.io/repo-name`
5. Open that URL on your Android phone in Chrome
6. Chrome will show "Add to Home Screen" banner — tap Install ✅

### Option B: Host on Netlify (free, drag & drop)
1. Go to netlify.com → sign up free
2. Drag the entire folder onto the Netlify dashboard
3. Get a live URL instantly
4. Open on Android Chrome → install prompt appears

### Option C: Local network (no internet needed)
1. Install Node.js on your computer
2. In this folder run: `npx serve .`
3. Note the IP address shown (e.g. 192.168.1.5:3000)
4. On Android, open Chrome and go to that IP
5. Tap the menu (⋮) → "Add to Home screen"

## PWA Features
- ✅ Installable on Android & iOS home screen
- ✅ Works offline (service worker caches all assets)
- ✅ Fullscreen mode (no browser UI)
- ✅ Data persists via localStorage
- ✅ Responsive layout for phones & tablets
- ✅ App icon on home screen

## Requirements
- Must be served over HTTPS for install prompt (GitHub Pages & Netlify do this automatically)
- Android Chrome 67+ or iOS Safari 11.3+
